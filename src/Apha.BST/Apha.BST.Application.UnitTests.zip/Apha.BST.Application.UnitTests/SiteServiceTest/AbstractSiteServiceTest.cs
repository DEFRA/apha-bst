﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Apha.BST.Application.DTOs;
using Apha.BST.Application.Interfaces;
using Apha.BST.Application.Services;
using Apha.BST.Core.Entities;
using Apha.BST.DataAccess.Data;
using Apha.BST.DataAccess.Repositories;
using AutoMapper;

namespace Apha.BST.Application.UnitTests.Services
{
    public class AbstractSiteServiceTest
    {
        protected readonly ISiteService _siteService;
        protected readonly SiteRepository _siteRepository;
        protected readonly BSTContext _dbContext;
        protected readonly IMapper _mapper;

        protected AbstractSiteServiceTest()
        {
            _dbContext = InMemorySiteContext.CreateContext();

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Site, SiteDTO>()
                   .ForMember(dest => dest.PlantNo, opt => opt.MapFrom(src => src.PlantNo))
                   .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Name));
            });

            _mapper = config.CreateMapper();
            _siteRepository = new SiteRepository(_dbContext);
            _siteService = new SiteService(_siteRepository, _mapper);
        }
    }
}
