﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Apha.BST.Core.Entities;
using Apha.BST.DataAccess.Data;
using Microsoft.EntityFrameworkCore;

namespace Apha.BST.Application.UnitTests.Services
{
    public class InMemorySiteContext
    {
        public static BSTContext CreateContext()
        {
            var options = new DbContextOptionsBuilder<BSTContext>()
                .UseInMemoryDatabase(databaseName: "Test_SiteDb")
                .Options;

            var dbContext = new BSTContext(options);

            dbContext.Database.EnsureDeleted();
            dbContext.Database.EnsureCreated();

            dbContext.Sites.AddRange(new List<Site>
        {
            new Site { PlantNo = "PLANT001", Name = "Site 1" },
            new Site { PlantNo = "PLANT002", Name = "Site 2" },
            // This entry will not be used in tests, included for clarity
            new Site { PlantNo = "PLANT_OTHER",Name = "Site Other" }
        });

            dbContext.SaveChanges();
            return dbContext;
        }
    }
}
